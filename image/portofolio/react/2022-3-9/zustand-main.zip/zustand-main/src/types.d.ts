// eslint-disable-next-line no-var
declare var __DEV__: boolean
